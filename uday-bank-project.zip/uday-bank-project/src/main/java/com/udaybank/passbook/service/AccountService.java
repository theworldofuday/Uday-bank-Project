package com.udaybank.passbook.service;

import com.udaybank.passbook.model.*;
import com.udaybank.passbook.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Transactional
    public void credit(Long accountNumber, BigDecimal amount, String description) {
        Account account = accountRepository.findById(accountNumber)
                .orElseThrow(() -> new RuntimeException("Account not found"));
        account.setBalance(account.getBalance().add(amount));

        Transaction transaction = new Transaction(LocalDateTime.now(), description, amount, "Credit", account);
        transactionRepository.save(transaction);
        accountRepository.save(account);
    }

    @Transactional
    public void debit(Long accountNumber, BigDecimal amount, String description) {
        Account account = accountRepository.findById(accountNumber)
                .orElseThrow(() -> new RuntimeException("Account not found"));

        if (account.getBalance().compareTo(amount) < 0) {
            throw new RuntimeException("Insufficient funds");
        }
        account.setBalance(account.getBalance().subtract(amount));

        Transaction transaction = new Transaction(LocalDateTime.now(), description, amount, "Debit", account);
        transactionRepository.save(transaction);
        accountRepository.save(account);
    }
}