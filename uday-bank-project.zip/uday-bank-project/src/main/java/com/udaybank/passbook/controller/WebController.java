package com.udaybank.passbook.controller;

import com.udaybank.passbook.model.Account;
import com.udaybank.passbook.model.Transaction; // <-- Important import
import com.udaybank.passbook.model.User;
import com.udaybank.passbook.repository.UserRepository;
import com.udaybank.passbook.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.util.Comparator;

@Controller
public class WebController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AccountService accountService;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userRepository.findByUsername(auth.getName()).orElseThrow(() -> new RuntimeException("User not found"));
        Account account = user.getAccount();

        model.addAttribute("username", user.getUsername());
        model.addAttribute("accountNumber", account.getAccountNumber());
        model.addAttribute("balance", account.getBalance());

        return "dashboard";
    }

    @PostMapping("/transaction")
    public String handleTransaction(@RequestParam String type, @RequestParam BigDecimal amount, @RequestParam String description) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userRepository.findByUsername(auth.getName()).orElseThrow(() -> new RuntimeException("User not found"));
        Long accountNumber = user.getAccount().getAccountNumber();

        if ("credit".equalsIgnoreCase(type)) {
            accountService.credit(accountNumber, amount, description);
        } else if ("debit".equalsIgnoreCase(type)) {
            accountService.debit(accountNumber, amount, description);
        }
        return "redirect:/dashboard";
    }

    @GetMapping("/passbook")
    public String passbook(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userRepository.findByUsername(auth.getName()).orElseThrow(() -> new RuntimeException("User not found"));
        Account account = user.getAccount();

        // Sort transactions by date, most recent first
        account.getTransactions().sort(Comparator.comparing(Transaction::getDate).reversed());

        model.addAttribute("accountNumber", account.getAccountNumber());
        model.addAttribute("transactions", account.getTransactions());
        return "passbook";
    }
}