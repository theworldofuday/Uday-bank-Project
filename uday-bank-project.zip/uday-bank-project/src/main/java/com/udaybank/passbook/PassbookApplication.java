package com.udaybank.passbook;

import com.udaybank.passbook.model.User;
import com.udaybank.passbook.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

// We are not importing or using Account or AccountService for this test
// to keep it as simple as possible.

@SpringBootApplication
public class PassbookApplication {

    public static void main(String[] args) {
        SpringApplication.run(PassbookApplication.class, args);
    }

    @Bean
    CommandLineRunner run(UserRepository userRepository, PasswordEncoder passwordEncoder) { // NOTE: AccountService has been removed
        return args -> {
            // Using a brand new username to guarantee a fresh start
            if (userRepository.findByUsername("finaltest").isEmpty()) {
                System.out.println("Creating new user 'finaltest'...");

                // Create a user with NO account for now
                User user = new User("finaltest", passwordEncoder.encode("password123"), "1234");

                userRepository.save(user); // Just save the user

                System.out.println("'finaltest' created successfully.");
            }
        };
    }
}