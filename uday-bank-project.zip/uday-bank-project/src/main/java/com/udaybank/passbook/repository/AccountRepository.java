// AccountRepository.java
package com.udaybank.passbook.repository;
import com.udaybank.passbook.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AccountRepository extends JpaRepository<Account, Long> {}
